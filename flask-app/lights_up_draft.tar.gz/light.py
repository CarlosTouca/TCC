class Light(object):
  
  #id do sensor
  SENSOR_ID = 0
  VALUE = 0
  def __init__(self, value, id):
    #set sensor initial value and id
    self.VALUE = value
    self.SENSOR_ID = id

  def read_sensor(self):
    #http GET no id do sensor
    return self.VALUE

  def change_led(self, value):
    self.VALUE = value
